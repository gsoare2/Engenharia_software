package matchband;

import static org.junit.Assert.*;

import org.junit.Test;

public class Teste {

	@Test
	public void test() {
		/*fail("Not yet implemented");*/
		
		Model model = new Model();
		
		model.cadastrarBanda(new Banda("Fox Rangers", "fox_metal@bol.com", "156651", "foto1.jpg", "Uma banda cujo o obejtivo � trazer paz e harmonia na musica", "RedFox, GrayFox, WhiteFox", "Variado", "Flexivel"));
		model.cadastrarBanda(new Banda("Guns N Roses", "gun@guns.com", "12587", "oficial.jpg", "Uma banda classica", "Alx Rose, Slash, Duff, Steven, Izzy", "HardRock", "Criativo"));
		
		//Teste de quantidade de cadastro
		assertEquals(model.getBanda().size(), 2);
		
		assertEquals(model.pesquisarBandaPorGeneroMusical("Country").size(), 0);
	}

}
