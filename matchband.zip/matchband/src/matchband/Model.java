package matchband;

import java.util.List;
import java.util.LinkedList;

public class Model {
	
	
	private List<Banda> bandas = new LinkedList<Banda>();
	private List<Musico> musicos = new LinkedList<Musico>();
	
	
	public void cadastrarBanda(Banda banda){
		bandas.add(banda);
	}
	
	public void cadastrarMusico(Musico musico){
		musicos.add(musico);
	}
	
	
	public List<Banda> pesquisarBandaPorGeneroMusical(String generoMusical){
		List<Banda> bandaEncontrada = new LinkedList<Banda>();
		for(Banda banda : this.bandas){
			if(banda.getGeneroMusical().equals(generoMusical)){
				bandaEncontrada.add(banda);
			}
		}
		return bandaEncontrada; 
	}
	
	//public List<Musico> pesquisarMusicoPorGenero
	
	public List<Banda> getBanda(){
		return this.bandas;
	}
}