package matchband;

public class Banda {
	
	private String nomeBanda,email,senha,foto,descricao,membros,generoMusical,tipoMusico;
	
	public Banda(String nomeBanda, String email, String senha, String foto, String descricao, String membros, String generoMusical, String tipoMusico){
		
		this.nomeBanda = nomeBanda;
		this.email = email;
		this.senha = senha;
		this.foto = foto;
		this.descricao = descricao;
		this.membros = membros;
		this.generoMusical = generoMusical;
		this.tipoMusico = tipoMusico;
	}
	
	public String getNomeBanda() {
		return nomeBanda;
	}


	public void setNomeBanda(String nomeBanda) {
		this.nomeBanda = nomeBanda;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getSenha() {
		return senha;
	}


	public void setSenha(String senha) {
		this.senha = senha;
	}


	public String getFoto() {
		return foto;
	}


	public void setFoto(String foto) {
		this.foto = foto;
	}


	public String getDescricao() {
		return descricao;
	}


	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}


	public String getMembros() {
		return membros;
	}


	public void setMembros(String membros) {
		this.membros = membros;
	}


	public String getGeneroMusical() {
		return generoMusical;
	}


	public void setGeneroMusical(String generoMusical) {
		this.generoMusical = generoMusical;
	}


	public String getTipoMusico() {
		return tipoMusico;
	}


	public void setTipoMusico(String tipoMusico) {
		this.tipoMusico = tipoMusico;
	}


}
